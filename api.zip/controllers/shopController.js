import Category from "../models/category.js";
import Product from "../models/product.js";
import Review from "../models/review.js";
import { getNextSequence } from "../utils/getNextSequence.js";

// GET /shop/categories
export const getCategories = async (req, res) => {
  try {
    const categories = await Category.find();
    res.status(200).json(categories);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// GET /shop/products
export const getProducts = async (req, res) => {
  try {
    const { id, category, q, page = 1, limit = 50, sort = "title" } = req.query;

    if (id != null && id !== "") {
      const productId = isNaN(Number(id)) ? id : Number(id);
      const product = await Product.findOne({ id: productId });
      if (!product)
        return res.status(404).json({ message: "Product not found" });
      return res.status(200).json(product);
    }

    const perPage = Math.min(Number(limit) || 50, 100);
    const skip = (Math.max(Number(page), 1) - 1) * perPage;

    const filter = {};

    if (category != null && category !== "") {
      filter["category.slug"] = String(category);
    }

    if (q) {
      filter.$or = [
        { title: { $regex: q, $options: "i" } },
        { description: { $regex: q, $options: "i" } },
      ];
    }

    const [items, total] = await Promise.all([
      Product.find(filter).sort(sort).skip(skip).limit(perPage),
      Product.countDocuments(filter),
    ]);

    res.status(200).json({
      items,
      total,
      page: Number(page),
      pages: Math.ceil(total / perPage),
    });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// GET /shop/products/:id
export const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const productId = isNaN(Number(id)) ? id : Number(id);
    const product = await Product.findOne({ id: productId });

    if (!product) return res.status(404).json({ message: "Product not found" });
    res.status(200).json(product);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// GET /shop/reviews
export const getReviews = async (req, res) => {
  try {
    const { productId, limit } = req.query;

    const perPage = Number(limit) || 0;

    const filter = {};
    if (productId != null && productId !== "") {
      const asNum = Number(productId);
      filter.productId = Number.isNaN(asNum) ? productId : asNum;
    }

    const query = Review.find(filter).sort({ date: -1 });
    if (perPage > 0) {
      query.limit(perPage);
    }

    const items = await query;
    res.status(200).json(items);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

// POST /shop/reviews
const nexReviewtId = await getNextSequence("reviewId");

export const addReview = async (req, res) => {
  try {
    const { productId, rating, comment, reviewerName, reviewerEmail } =
      req.body;

    const productIdNum = Number(productId);
    if (!productId || Number.isNaN(productIdNum)) {
      return res
        .status(400)
        .json({ message: "productId must be a number (1..N)" });
    }
    const rNum = Number(rating);
    if (!rNum || rNum < 1 || rNum > 5) {
      return res
        .status(400)
        .json({ message: "rating must be an integer 1..5" });
    }
    if (!reviewerName || typeof reviewerName !== "string") {
      return res.status(400).json({ message: "reviewerName is required" });
    }
    const emailOk =
      typeof reviewerEmail === "string" && /^\S+@\S+$/.test(reviewerEmail);
    if (!emailOk) {
      return res.status(400).json({ message: "reviewerEmail is invalid" });
    }

    const product = await Product.findOne({ id: productIdNum });
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const reviewDoc = await Review.create({
      id: nexReviewtId,
      productId: productIdNum,
      rating: rNum,
      comment: comment || "",
      reviewerName,
      reviewerEmail,
      date: new Date(),
    });

    return res.status(201).json(reviewDoc);
  } catch (err) {
    return res.status(500).json({ message: "Server error" });
  }
};
